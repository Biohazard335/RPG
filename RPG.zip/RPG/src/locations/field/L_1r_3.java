package locations.field;

import locations.Lolcation;
import Talk.talkers.Talker;
import fight.classes.Fighter;

public class L_1r_3 extends Lolcation {
	public L_1r_3() {
		super(
				-1,
				-3,
				0,
				"Field",
				"In the clearing there is a large statue, there appears"
						+ " to be a piece missing. To the East the field continues,"
						+ " there is a mountain path to the NorthWest."
						+ " \nThe south is blocked by the river, the North is blocked by the mountains.",
				new Object[] { "West", "East" }, new Fighter[] {},
				new Talker[] {});
	}
}
