package locations.field.mountainPath;

import locations.Lolcation;
import Talk.talkers.Talker;
import fight.classes.Fighter;

public class L_2r_2 extends Lolcation {
	public L_2r_2() {
		super(
				-2,
				-2,
				0,
				"Mountain Path",
				"The path leads North towards some sort of entrance. \nTo the South is a field.",
				new Object[] { "North", "South" }, new Fighter[] {},
				new Talker[] {});
	}
}
