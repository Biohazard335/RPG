package locations.field;

import locations.Lolcation;
import Talk.talkers.Talker;
import fight.classes.Fighter;

public class L1r_4 extends Lolcation {
	public L1r_4() {
		super(
				1,
				-4,
				0,
				"Field",
				"The North is blocked by the river, the South is blocked by the"
						+ " mountains. High on the mountain you can see some sort of castle. To the NorthEast there is a bridge,"
						+ " to the far West a small Village.", new Object[] {
						"West", "East" }, new Fighter[] {}, new Talker[] {});
	}
}
