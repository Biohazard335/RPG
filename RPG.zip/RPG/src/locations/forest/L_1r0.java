package locations.forest;

import locations.Lolcation;
import Talk.talkers.Talker;
import fight.classes.Fighter;

public class L_1r0 extends Lolcation {
	public L_1r0() {
		super(
				-1,
				0,
				0,
				"Forest",
				"The edge of the forest yeilds to a mountainside. The West and South are blocked",
				new Object[] { "North", "East" }, new Fighter[] {},
				new Talker[] {});
	}
}
