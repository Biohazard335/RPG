package locations;
/*
 * package locations;
 * 
 * import items.ArmoryKey; import items.Back; import items.BronzeArmor; import
 * items.BronzeSword; import items.DungeonKey; import items.Item; import
 * items.LeatherArmor; import items.RebelMap; import items.RustyDagger; import
 * items.SteelSword;
 * 
 * import java.io.BufferedReader; import java.io.FileReader; import
 * java.util.ArrayList;
 * 
 * import javax.swing.JOptionPane;
 * 
 * import locations.dungeon.L_2r0r_1; import locations.field.L0r_3; import
 * locations.field.L0r_4; import locations.field.L1r_3; import
 * locations.field.L1r_4; import locations.field.L2r_3; import
 * locations.field.L2r_4; import locations.field.L_1r_3; import
 * locations.field.L_1r_4; import locations.field.L_2r_3; import
 * locations.field.mountainPath.L_2r0; import
 * locations.field.mountainPath.L_2r_1; import
 * locations.field.mountainPath.L_2r_2; import locations.forest.L0r1; import
 * locations.forest.L0r2; import locations.forest.L1r0; import
 * locations.forest.L1r1; import locations.forest.L1r2; import
 * locations.forest.L2r1; import locations.forest.L_1r0; import
 * locations.forest.L_1r1; import locations.forest.L_1r2; import
 * locations.forest.L_2r1; import locations.forest.valley.L0r_2; import
 * locations.forest.valley.Start; import locations.forest.valley.cave.L_1r_1;
 * import locations.forest.valley.cave.L_1r_2; import menu.AdminMaker; import
 * menu.Menu; import menu.Open; import Talk.conversation; import
 * Talk.talkers.Talker; import fight.Battle; import fight.classes.ADMIN; import
 * fight.classes.Fighter; import fight.classes.Player;
 * 
 * public class Game { public static int x = 0, y = -1, z = 0; public static
 * Lolcation location = new Basic(); public static Object direction = "North";
 * public static Fighter player; public static Lolcation[] locations = { new
 * Basic(), new L_1r_1(), new L_1r_2(), new L_1r_3(), new L_1r_4(), new L_1r0(),
 * new L_1r1(), new L_1r2(), new L_2r_1(), new L_2r_2(), new L_2r_3(), new
 * L_2r0(), new L_2r1(), new L_2r0r_1(), new L0r_2(), new L0r_3(), new L0r_4(),
 * new L0r1(), new L0r2(), new L1r_3(), new L1r_4(), new L1r0(), new L1r1(), new
 * L1r2(), new L2r_3(), new L2r_4(), new L2r1(), new Start() }; public static
 * Item[] items = { new ArmoryKey(), new LeatherArmor(), new BronzeSword(), new
 * RebelMap(), new Back(), new SteelSword(), new BronzeArmor(), new
 * RustyDagger(), new DungeonKey() }; public static int f = 1;
 * 
 * public static void main(String[] args) { player = new Player();
 * 
 * JOptionPane.showMessageDialog(null,
 * "Welcome to Dethland. You will most likely not survive.", "Welcome",
 * JOptionPane.PLAIN_MESSAGE); while (player.name == null ||
 * player.name.isEmpty()) { player.name = JOptionPane.showInputDialog(null,
 * "What is your name?", "Welcome", JOptionPane.PLAIN_MESSAGE); int i =
 * JOptionPane.showConfirmDialog(null, "You said your name was " + player.name +
 * ", right?", "Welcome", JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE,
 * null); if (i != 0) player.name = null; try { BufferedReader reader = new
 * BufferedReader(new FileReader( "./data/saveFiles.txt")); String line; while
 * ((line = reader.readLine()) != null) { if (line.contains(player.name)) { int
 * y = JOptionPane.showConfirmDialog(null, "Continue saved game?", "Continue",
 * JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null); if (y == 0) {
 * Open.open(); break; } } } reader.close(); } catch (Exception stupid) {
 * stupid.printStackTrace(); } } if (player.name.equals("ADMIN")) { player = new
 * ADMIN(); AdminMaker.ADMiN();
 * 
 * } else { do { game(); Menu.menu(); if (f == 0) break; } while (true); } }
 * 
 * public static void game() { do { for (Lolcation l : locations) { if (l.x == x
 * && l.y == y && l.z == z) { location = l; break; } } location.before(); if
 * (location.check == true) { String area = (String) location.area; if
 * (player.name == "ADMIN") area += " " + x + "," + y + "," + z; direction =
 * JOptionPane.showInputDialog(null, location.description, area,
 * JOptionPane.PLAIN_MESSAGE, null, location.options, location.options[0]);
 * 
 * if (direction == "North") y += 1; else if (direction == "South") y -= 1; else
 * if (direction == "West") x -= 1; else if (direction == "East") x += 1; else
 * if (direction == "Up") z += 1; else if (direction == "Down") z -= 1; else if
 * (direction == "Fight!") { if (location.fighters.length != 0) if
 * (location.fighters.length == 1) Battle.battle(player, location.fighters[0]);
 * else { Fighter fght = null; ArrayList<String> fighters = new
 * ArrayList<String>(); for (Fighter f : location.fighters) {
 * fighters.add(f.name); } String[] fight = fighters .toArray(new
 * String[fighters.size()]); String tchoice = (String) JOptionPane
 * .showInputDialog(null, "Talk to who?", "Talk", JOptionPane.PLAIN_MESSAGE,
 * null, fight, fight[0]); if (tchoice != null) { for (Fighter f :
 * location.fighters) if (f.name.equals(tchoice)) fght = f;
 * Battle.battle(player, fght); } } } else if (direction == "Talk") { if
 * (location.talkers.length != 0) if (location.talkers.length == 1)
 * conversation.go(location.talkers[0]); else { Talker tlk = null;
 * ArrayList<String> talkers = new ArrayList<String>(); for (Talker t :
 * location.talkers) { talkers.add(t.name); } String[] talk =
 * talkers.toArray(new String[talkers .size()]); String tchoice = (String)
 * JOptionPane .showInputDialog(null, "Talk to who?", "Talk",
 * JOptionPane.PLAIN_MESSAGE, null, talk, talk[0]); if (tchoice != null) { for
 * (Talker t : location.talkers) if (t.name.equals(tchoice)) tlk = t;
 * conversation.go(tlk); } } } else if (direction != null) location.after(); } }
 * while (direction != null); }
 * 
 * }
 */