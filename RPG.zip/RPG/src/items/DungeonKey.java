package items;

public class DungeonKey extends Item {
	public DungeonKey() {
		super(false, "item");
	}

}
