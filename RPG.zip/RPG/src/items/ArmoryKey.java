package items;

public class ArmoryKey extends Item {

	public ArmoryKey() {
		super(false, "item");
	}

}
