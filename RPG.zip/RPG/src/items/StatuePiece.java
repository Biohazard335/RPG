package items;

public class StatuePiece extends Item {
	public StatuePiece() {
		super(false, "item");
	}

}
