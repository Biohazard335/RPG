package items;

public class RebelMap extends Item {

	public RebelMap() {
		super(false, "item");
	}

}
