package items;

public class Back extends Item {

	public Back() {
		super(true, "none");
		this.has = true;
	}

}
