package fight.attacks;

public class Strike extends Attack {
	public Strike() {
		super(10, 4, 5, 2, "struck");
	}

}
