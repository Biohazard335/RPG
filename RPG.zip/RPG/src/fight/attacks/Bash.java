package fight.attacks;

public class Bash extends Attack {

	public Bash() {
		super(8, 6, 4, 4, "used an arm to smash");
	}

}
