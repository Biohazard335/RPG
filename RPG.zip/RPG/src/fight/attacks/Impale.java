package fight.attacks;

public class Impale extends Attack {
	public Impale() {
		super(5, 10, 4, 4, "used a sword to impale");
	}
}
