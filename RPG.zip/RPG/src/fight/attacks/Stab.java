package fight.attacks;

public class Stab extends Attack {

	public Stab() {
		super(8, 6, 5, 2, "used a dagger to stab");
	}

}
