package fight.attacks;

public class Masticate extends Attack {

	public Masticate() {
		super(8, 15, 8, 5, "viciously masticated");
	}

}
