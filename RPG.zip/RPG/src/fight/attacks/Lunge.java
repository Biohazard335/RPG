package fight.attacks;

public class Lunge extends Attack {

	public Lunge() {
		super(6, 4, 5, 0, "lunged at");
	}

}
