package fight.attacks;

public class Punch extends Attack {

	public Punch() {
		super(10, 2, 8, 0, "punched");
	}

}
