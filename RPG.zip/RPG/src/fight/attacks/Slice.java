package fight.attacks;

public class Slice extends Attack {

	public Slice() {
		super(5, 8, 4, 3, "used a sword to slice");
	}

}
