package fight.attacks;

public class Bite extends Attack {

	public Bite() {
		super(8, 8, 5, 4, "used fangs to bite");
	}

}
