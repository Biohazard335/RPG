package fight.attacks;

public class Kick extends Attack {

	public Kick() {
		super(5, 4, 5, 1, "kicked");
	}

}
