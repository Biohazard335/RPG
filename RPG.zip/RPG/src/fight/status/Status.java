package fight.status;

import fight.classes.Fighter;

public class Status {
	int turns;

	public Status(int turns) {
		this.turns = turns;

	}

	public void effect(Fighter affected) {

	}

}
